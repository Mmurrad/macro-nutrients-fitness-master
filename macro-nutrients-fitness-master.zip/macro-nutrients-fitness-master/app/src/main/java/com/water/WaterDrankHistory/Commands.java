package com.water.WaterDrankHistory;


public class Commands {
    public static String DateLogItem= "date_log_item";
}
